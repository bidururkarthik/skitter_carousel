// // App.js
// import React, { useEffect } from 'react';
import $ from 'jquery';

import React, { useEffect } from 'react';
import 'skitter-slider/dist/skitter.css';
import 'jquery-ui-bundle';
import 'jquery-ui-bundle/jquery-ui.min.css';
import "jquery-ui-dist/jquery-ui";
window.jQuery = window.$ ;

const SkitterSlider = () => {
  useEffect(() => {
    // Initialize the skitter-slider
    // const script = document.createElement('script')
    // script.src = '/skitter/jquery.skitter.min.js'
    // document.body.appendChild(script)

    // const skitter = document.createElement('skitter')
    // skitter.src = '/skitter/jquery.skitter.js'
    // document.body.appendChild(skitter)

    
    // const easy = document.createElement('easy')
    // easy.src = '/skitter/jquery.easing.1.3.js'
    // document.body.appendChild(easy)


    $(document).ready(function() {
        $(".skitter-large").skitter();
      })
  }, []);

  return (
    <div className="skitter skitter-large">
      <ul>
        <li>
          <a href="#cut">
            <img src="/photoshop.jpg" className="cut" width="500" height="300" alt="cut" />
          </a>
          <div className="label_text">
            <p>cut</p>
          </div>
        </li>
        <li>
          <a href="#swapBlocks">
            <img src="/tools-table.jpg" className="swapBlocks" width="500" height="300" alt="swapBlocks" />
          </a>
          <div className="label_text">
            <p>swapBlocks</p>
          </div>
        </li>
        <li>
          <a href="#swapBarsBack">
            <img src="/male-worker-factory.jpg" className="swapBarsBack" width="500" height="300" alt="swapBarsBack" />
          </a>
          <div className="label_text">
            <p>swapBarsBack</p>
          </div>
        </li>
        <li>
          <a href="#cube">
            <img src="/car.jpg" className="cube" width="500" height="300" alt="cube" />
          </a>
          <div className="label_text">
            <p>cube</p>
          </div>
        </li>
      </ul>
    </div>
  );
};

export default SkitterSlider;
