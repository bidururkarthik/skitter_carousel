// App.js
import React from 'react';
import SkitterSlider from './Component/SkitterSlider';
import './App.css'

const App = () => {
  return (
    <div className="App">
      <h1>React Skitter Slider</h1>
      <SkitterSlider/>
    </div>
  );
};

export default App;
